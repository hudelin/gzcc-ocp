package com.hdl.gzccocpcore.social.qq.api;

public class QQUserInfo {

}
