package com.hdl.gzccocpcore.constant;

public class BaseErrorConstant {
}
