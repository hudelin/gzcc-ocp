/**
 * 
 */
package com.hdl.gzccocpcore.properties;

/**
 * @author zhailiang
 *
 */
public enum LoginResponseType {
	
	/**
	 * 跳转
	 */
	REDIRECT,
	
	/**
	 * 返回json
	 */
	JSON

}
