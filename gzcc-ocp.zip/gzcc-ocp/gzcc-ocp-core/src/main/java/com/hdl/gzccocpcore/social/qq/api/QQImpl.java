//package com.hdl.gzccocpcore.social.qq.api;
//
//public class QQImpl extends AbstractOAuth2ApiBinding implements QQ {
//    @Override
//    public QQUserInfo getUserInfo()  {
//        return null;
//    }
//}
