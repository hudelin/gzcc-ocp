package com.hdl.gzccocpcore.repository;

import com.hdl.gzccocpcore.entity.Friend;
import com.hdl.gzccocpcore.entity.Message;

import java.util.List;

public interface MessageRepository extends BaseRepository<Message, Long> {


}
