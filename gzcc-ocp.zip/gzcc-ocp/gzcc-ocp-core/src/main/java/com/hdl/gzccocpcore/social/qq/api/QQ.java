package com.hdl.gzccocpcore.social.qq.api;

public interface QQ {

    QQUserInfo getUserInfo();
}
