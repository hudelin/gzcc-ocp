package com.hdl.gzccocpcore.properties;

public class ValidateCodeProperties {

    private ImageCodeProperties imageCodeProperties=new ImageCodeProperties();

    public ImageCodeProperties getImageCodeProperties() {
        return imageCodeProperties;
    }

    public void setImageCodeProperties(ImageCodeProperties imageCodeProperties) {
        this.imageCodeProperties = imageCodeProperties;
    }
}
